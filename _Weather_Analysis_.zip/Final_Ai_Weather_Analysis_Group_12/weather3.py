import requests
import tkinter as tk
from tkinter import Label, Frame, PhotoImage, Canvas
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns

# Function to fetch current weather data from OpenWeatherMap API
def fetch_current_weather(city, api_key):
    url = f"http://api.openweathermap.org/data/2.5/weather?q={city}&units=metric&appid={api_key}"
    response = requests.get(url)
    if response.status_code == 200:
        return response.json()
    else:
        print("Error:", response.status_code, response.text)
        return None

# Function to fetch weather forecast data from OpenWeatherMap API
def fetch_weather_data(city, api_key):
    url = f"http://api.openweathermap.org/data/2.5/forecast?q={city}&units=metric&appid={api_key}"
    response = requests.get(url)
    if response.status_code == 200:
        return response.json()
    else:
        print("Error:", response.status_code, response.text)
        return None

# Function to process API data
def process_weather_data(data):
    forecast = []
    for entry in data['list']:
        forecast.append({
            'datetime': entry['dt_txt'],
            'temperature': entry['main']['temp'],
            'weather': entry['weather'][0]['main']
        })
    df = pd.DataFrame(forecast)
    df['datetime'] = pd.to_datetime(df['datetime'])
    return df

# Function to plot the temperature trend for a specific day
def plot_temperature_trend(df, day_index):
    day_data = df[day_index*8:(day_index+1)*8]  # Each day has 8 time entries (3-hour intervals)
    day_name = day_data['datetime'].iloc[0].strftime('%A')  # Get the day name

    # Set the modern theme
    sns.set_theme(style="darkgrid")
    plt.figure(figsize=(10, 5))

    # Set the background and grid colors
    plt.gca().set_facecolor("#1E1E2E")  # Dark background
    plt.gcf().set_facecolor("#1E1E2E")
    plt.grid(color="#44475a", linestyle="--", linewidth=0.7)

    # Line plot with styled markers
    sns.lineplot(
        data=day_data,
        x='datetime',
        y='temperature',
        marker='o',
        color="#4CAF50",
        linewidth=2.5,
        markersize=8
    )

    # Customize labels and title
    plt.title(f'Temperature Trend - {day_name}', fontsize=16, color="white", pad=15)
    plt.xlabel('Time', fontsize=12, color="white")
    plt.ylabel('Temperature (°C)', fontsize=12, color="white")
    plt.xticks(
        day_data['datetime'], 
        day_data['datetime'].dt.strftime('%I:%M %p'),  # Display in 12-hour AM/PM format
        rotation=45,
        color="white",
        fontsize=10
    )
    plt.yticks(color="white", fontsize=10)

    # Tight layout and render the graph in the Tkinter frame
    plt.tight_layout()
    canvas = FigureCanvasTkAgg(plt.gcf(), master=frame_graph)
    canvas.draw()
    canvas.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH, expand=True)

# Function to update the graph display area
def clear_and_update_graph():
    for widget in frame_graph.winfo_children():
        widget.destroy()  # Clear the previous graph

# Function to generate a weather description based on temperature and conditions
def generate_weather_description(temp, condition):
    if "rain" in condition.lower():
        return "It's raining. Don't forget an umbrella!"
    elif temp < 10:
        return "It's cold. Wear something warm!"
    elif 10 <= temp <= 25:
        return "It's pleasant. Enjoy the weather!"
    elif temp > 25:
        return "It's hot. Stay hydrated!"
    else:
        return "Weather conditions are moderate."

# Function to update GUI with weather data
def update_gui(city, api_key):
    # Fetch current weather
    current_data = fetch_current_weather(city, api_key)
    if not current_data:
        label_city.config(text=f"City: {city}\nError fetching current weather data")
        return

    current_temp = current_data['main']['temp']
    current_weather = current_data['weather'][0]['main']
    description = generate_weather_description(current_temp, current_weather)

    # Fetch forecast data
    forecast_data = fetch_weather_data(city, api_key)
    if not forecast_data:
        label_city.config(text=f"City: {city}\nError fetching forecast data")
        return

    # Process forecast data
    df = process_weather_data(forecast_data)

    # Update labels with current weather
    label_city.config(text=f"City: {city}")
    label_temp.config(text=f"Current Temperature: {round(current_temp, 1)}°C")
    label_weather.config(text=f"Weather: {current_weather}")
    label_description.config(text=description)

    # Plot for the first day (default)
    clear_and_update_graph()  # Clear the previous graph
    plot_temperature_trend(df, 0)  # Display the plot for the first day

    # Store the DataFrame globally for later use with buttons
    global forecast_df
    forecast_df = df

    # Update the button labels with the correct dates and weather icons
    update_button_dates(df)

# Function to handle button clicks to display the graph for each day
def show_day_graph(day_index):
    clear_and_update_graph()  # Clear the previous graph
    plot_temperature_trend(forecast_df, day_index)  # Display the plot for the selected day

# Function to update button labels with the corresponding dates and weather icons
def update_button_dates(df):
    for i in range(5):
        date = df['datetime'].iloc[i*8].strftime('%Y-%m-%d')  # Get the date for each day
        day_name = df['datetime'].iloc[i*8].strftime('%A')  # Get the day name

        # Get the weather condition for the first 3-hour interval of the day
        weather_condition = df['weather'].iloc[i*8]

        # Set the icon based on the weather condition
        if "rain" in weather_condition.lower():
            icon = icon_rainy
        elif "cloud" in weather_condition.lower():
            icon = icon_cloudy
        else:
            icon = icon_sunny  # Default to sunny if no specific condition is found

        # Create a label with the icon and date
        weather_text = f"{day_name}\n{date}"
        button_image = icon.subsample(8, 8)  # Resize the icon to smaller size

        # Update button text with the date and weather icon
        buttons[i].config(text=weather_text, image=button_image, compound="top", font=("Arial", 10), height=100, width=100)  # Adjust button dimensions
        buttons[i].image = button_image  # Keep a reference to the image

# Function to handle city search
def search_city():
    city = entry_city.get()  # Get the city name from the text entry
    if city.strip():  # Check if city is not empty
        update_gui(city, API_KEY)
    else:
        label_city.config(text="Please enter a valid city name.")

# GUI Setup
root = tk.Tk()
root.title("Weather Forecast")
root.geometry("1200x900")
root.configure(bg="#1E1E2E")  # Dark background for modern look

# Add a banner image
try:
    banner_img = PhotoImage(file="weather_banner.png")
    banner_label = Label(root, image=banner_img, bg="#1E1E2E")
    banner_label.pack()
except Exception as e:
    print("Error loading banner image:", e)

# Load weather icons (use placeholders if the images are missing)
try:
    icon_sunny = PhotoImage(file="sunny.png")
    icon_rainy = PhotoImage(file="rainy.png")
    icon_cloudy = PhotoImage(file="cloudy.png")
except Exception as e:
    print("Error loading icons:", e)
    icon_sunny = icon_rainy = icon_cloudy = None

# API Key and Default City
API_KEY = "1f8a87c509a97a3a570e139918708585"  # Replace with your OpenWeatherMap API Key
DEFAULT_CITY = "Islamabad"

# Top Frame: City Input and Search
frame_search = Frame(root, bg="#1E1E2E")
frame_search.pack(pady=10)

entry_city = tk.Entry(frame_search, width=20, font=("Arial", 14))
entry_city.insert(0, DEFAULT_CITY)  # Default value
entry_city.pack(side=tk.LEFT, padx=5)

button_search = tk.Button(frame_search, text="Search", command=search_city, font=("Arial", 12), bg="#4CAF50", fg="white", relief="flat")
button_search.pack(side=tk.LEFT)

# Existing GUI Frames (Top, Buttons, Graph)
frame_top = Frame(root, bg="#1E1E2E")
frame_top.pack(pady=10)

label_city = Label(frame_top, text="City: ", font=("Arial", 16), fg="white", bg="#1E1E2E")
label_city.pack()

label_temp = Label(frame_top, text="Current Temperature: ", font=("Arial", 16), fg="white", bg="#1E1E2E")
label_temp.pack()

label_weather = Label(frame_top, text="Weather: ", font=("Arial", 16), fg="white", bg="#1E1E2E")
label_weather.pack()

label_description = Label(frame_top, text="", font=("Arial", 14), fg="#4CAF50", bg="#1E1E2E")
label_description.pack()

frame_buttons = Frame(root, bg="#1E1E2E")
frame_buttons.pack(pady=10)

buttons = []
for i in range(5):  # Create 5 buttons for 5 days
    button = tk.Button(frame_buttons, text=f"Day {i+1}", command=lambda i=i: show_day_graph(i), font=("Arial", 12), bg="#4CAF50", fg="white", relief="flat", height=3, width=12)
    button.grid(row=0, column=i, padx=10)
    buttons.append(button)

frame_graph = Frame(root, bg="#1E1E2E")
frame_graph.pack(pady=20, fill=tk.BOTH, expand=True)

# Update data on launch
update_gui(DEFAULT_CITY, API_KEY)

root.mainloop()
